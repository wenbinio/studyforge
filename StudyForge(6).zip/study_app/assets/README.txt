Place optional assets here:
- icon.ico (for the .exe build)
- alarm.wav (for Pomodoro notifications — Windows MessageBeep is used as fallback)
